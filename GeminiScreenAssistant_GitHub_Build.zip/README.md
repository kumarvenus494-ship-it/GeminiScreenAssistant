# Gemini Screen Assistant (Android)

This is a native Android Studio Kotlin starter project for sequential prompt entry into the Gemini Android app using Android Accessibility.

## What it does
- Lets you paste multiple prompt parts.
- Splits parts at a line containing `---NEXT---`.
- When Gemini is foregrounded, attempts to find the composer and Send control, enters the current part, and taps Send.
- Waits for the visible accessibility tree to stop changing before moving to the next part.
- Stop immediately disables the queue.

## Important limitations
- This is UI automation, not an official Gemini integration. Gemini may change its UI, labels, package name, or accessibility tree. The composer/send selectors may need updating for your Gemini app version and language.
- The service reads the accessibility node tree, not a pixel-perfect screenshot or video of your display. It does not upload screen data.
- The completion detector is heuristic. It cannot guarantee that Gemini finished a response, and may need tuning. Test with harmless short prompts first; do not use it for unattended high-stakes actions.
- This project does not generate or export video clips itself. It only submits the prompts you provide to Gemini.
- The app does not bypass subscription limits, CAPTCHAs, or other access controls.

## Build
1. Install Android Studio (current stable) and Android SDK 35.
2. Open this folder as a project and let Gradle sync.
3. Build and install the `app` configuration on your Android phone.
4. Open the app, tap **Enable Accessibility**, then enable **Gemini Screen Assistant** in Android Settings.
5. Return to the app and paste prompts separated by a line containing `---NEXT---`.
6. Tap **Open Gemini**, open the chat where you want the parts submitted, then return to the assistant and tap **START AUTOMATION**.
7. Switch to Gemini and keep it in the foreground. Tap **STOP** in the assistant to halt (you may need to switch back to the assistant first).

## Example prompt sequence
PART 1: Create the first clip prompt...

---NEXT---

PART 2: Continue the same visual style...

## Privacy
Accessibility permission is powerful. Android may show a system warning. Enable this only for this project if you understand the behavior. The source is included for inspection. The app does not request Internet permission and has no analytics or backend.
