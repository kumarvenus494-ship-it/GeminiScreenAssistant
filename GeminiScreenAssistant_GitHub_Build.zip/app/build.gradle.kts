plugins {
    id("com.android.application")
    id("org.jetbrains.kotlin.android")
}
android {
    namespace = "com.mahesh.geminiscreenassistant"
    compileSdk = 35
    defaultConfig {
        applicationId = "com.mahesh.geminiscreenassistant"
        minSdk = 26
        targetSdk = 35
        versionCode = 1
        versionName = "1.0"
    }
}
