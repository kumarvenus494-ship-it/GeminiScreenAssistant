package com.mahesh.geminiscreenassistant

import android.accessibilityservice.AccessibilityService
import android.os.Handler
import android.os.Looper
import android.view.accessibility.AccessibilityEvent
import android.view.accessibility.AccessibilityNodeInfo
import android.widget.Toast

/**
 * UI automation helper. It only operates while the user has enabled this service
 * and Gemini is the foreground app. No credentials or screen contents are uploaded.
 */
class GeminiAccessibilityService : AccessibilityService() {
    private val handler = Handler(Looper.getMainLooper())
    private val prefs by lazy { getSharedPreferences("assistant", MODE_PRIVATE) }
    private var lastResponseSignature = ""
    private var stableCount = 0
    private var lastSentAt = 0L
    private var processing = false

    override fun onServiceConnected() {
        super.onServiceConnected()
        handler.post(poll)
    }

    override fun onAccessibilityEvent(event: AccessibilityEvent?) {
        if (event?.packageName?.toString() == GEMINI_PACKAGE) {
            handler.removeCallbacks(poll)
            handler.postDelayed(poll, 500)
        }
    }

    override fun onInterrupt() { }

    override fun onDestroy() {
        handler.removeCallbacks(poll)
        super.onDestroy()
    }

    private val poll = object : Runnable {
        override fun run() {
            try {
                if (!prefs.getBoolean("running", false)) {
                    processing = false
                    stableCount = 0
                    return
                }
                val root = rootInActiveWindow
                if (root == null || root.packageName?.toString() != GEMINI_PACKAGE) {
                    handler.postDelayed(this, 1200)
                    return
                }
                val chunks = prefs.getString("queue", "").orEmpty()
                    .split("\n\u001E\n").filter { it.isNotBlank() }
                val index = prefs.getInt("index", 0)
                if (index >= chunks.size) {
                    prefs.edit().putBoolean("running", false).apply()
                    toast("All prompt parts sent.")
                    return
                }

                val stopVisible = containsText(root, listOf("stop generating", "stop response", "stop"))
                val composer = findComposer(root)
                val sendButton = findSendButton(root)

                if (!prefs.getBoolean("sent", false)) {
                    if (stopVisible || composer == null || sendButton == null) {
                        handler.postDelayed(this, 1000)
                        return
                    }
                    val target = composer
                    target.performAction(AccessibilityNodeInfo.ACTION_FOCUS)
                    val args = android.os.Bundle().apply {
                        putCharSequence(AccessibilityNodeInfo.ACTION_ARGUMENT_SET_TEXT_CHARSEQUENCE, chunks[index])
                    }
                    val set = target.performAction(AccessibilityNodeInfo.ACTION_SET_TEXT, args)
                    if (set) {
                        handler.postDelayed({
                            val latest = rootInActiveWindow
                            val button = latest?.let { findSendButton(it) }
                            if (button != null) {
                                button.performAction(AccessibilityNodeInfo.ACTION_CLICK)
                                prefs.edit().putBoolean("sent", true).apply()
                                lastSentAt = System.currentTimeMillis()
                                stableCount = 0
                                lastResponseSignature = ""
                            }
                        }, 700)
                    }
                    handler.postDelayed(this, 1800)
                    return
                }

                // Wait for generation to finish, then require the visible response
                // tree to remain unchanged for several polls before sending next part.
                if (stopVisible) {
                    stableCount = 0
                    lastResponseSignature = responseSignature(root)
                } else if (System.currentTimeMillis() - lastSentAt > MIN_WAIT_MS) {
                    val signature = responseSignature(root)
                    if (signature.isNotEmpty() && signature == lastResponseSignature) stableCount++
                    else stableCount = 0
                    lastResponseSignature = signature
                    if (stableCount >= STABLE_POLLS && composer != null && sendButton != null) {
                        prefs.edit().putInt("index", index + 1).putBoolean("sent", false).apply()
                        stableCount = 0
                        processing = false
                        handler.postDelayed(this, 900)
                        return
                    }
                }
                handler.postDelayed(this, 1200)
            } catch (_: Exception) {
                handler.postDelayed(this, 1500)
            }
        }
    }

    private fun findComposer(root: AccessibilityNodeInfo): AccessibilityNodeInfo? {
        val byId = root.findAccessibilityNodeInfosByViewId("com.google.android.apps.bard:id/input_text")
        byId.firstOrNull()?.let { return it }
        return findFirst(root) { node ->
            node.isEditable && node.isEnabled && node.isVisibleToUser
        }
    }

    private fun findSendButton(root: AccessibilityNodeInfo): AccessibilityNodeInfo? =
        findFirst(root) { node ->
            if (!node.isClickable || !node.isEnabled || !node.isVisibleToUser) return@findFirst false
            val desc = (node.contentDescription?.toString() ?: "").lowercase()
            val text = (node.text?.toString() ?: "").lowercase()
            (desc.contains("send") || text == "send" || desc.contains("submit")) &&
                !desc.contains("stop")
        }

    private fun containsText(root: AccessibilityNodeInfo, terms: List<String>): Boolean {
        val nodes = ArrayList<AccessibilityNodeInfo>()
        collect(root, nodes)
        return nodes.any { node ->
            val value = ((node.text?.toString() ?: "") + " " +
                (node.contentDescription?.toString() ?: "")).lowercase()
            terms.any { value.contains(it) }
        }
    }

    private fun responseSignature(root: AccessibilityNodeInfo): String {
        val nodes = ArrayList<AccessibilityNodeInfo>()
        collect(root, nodes)
        return nodes.mapNotNull { it.text?.toString()?.trim() }
            .filter { it.isNotEmpty() }.takeLast(12).joinToString("|").take(1200)
    }

    private fun findFirst(root: AccessibilityNodeInfo, predicate: (AccessibilityNodeInfo) -> Boolean): AccessibilityNodeInfo? {
        if (predicate(root)) return root
        for (i in 0 until root.childCount) {
            val child = root.getChild(i) ?: continue
            val found = findFirst(child, predicate)
            if (found != null) return found
        }
        return null
    }

    private fun collect(root: AccessibilityNodeInfo, out: MutableList<AccessibilityNodeInfo>) {
        out.add(root)
        for (i in 0 until root.childCount) {
            val child = root.getChild(i) ?: continue
            collect(child, out)
        }
    }

    private fun toast(message: String) {
        handler.post { Toast.makeText(this, message, Toast.LENGTH_LONG).show() }
    }

    companion object {
        private const val GEMINI_PACKAGE = "com.google.android.apps.bard"
        private const val MIN_WAIT_MS = 5000L
        private const val STABLE_POLLS = 3
    }
}
