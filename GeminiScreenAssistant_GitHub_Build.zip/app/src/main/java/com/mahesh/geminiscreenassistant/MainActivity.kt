package com.mahesh.geminiscreenassistant

import android.app.Activity
import android.content.Intent
import android.net.Uri
import android.os.Bundle
import android.provider.Settings
import android.view.Gravity
import android.view.View
import android.view.accessibility.AccessibilityManager
import android.content.Context
import android.graphics.Typeface
import android.widget.*

class MainActivity : Activity() {
    private lateinit var prompts: EditText
    private lateinit var status: TextView
    private val prefs by lazy { getSharedPreferences("assistant", MODE_PRIVATE) }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        buildUi()
    }

    private fun buildUi() {
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(22, 24, 22, 18)
            setBackgroundColor(0xFFF7F7FB.toInt())
        }
        val title = TextView(this).apply {
            text = "Gemini Screen Assistant"
            textSize = 25f
            setTextColor(0xFF171725.toInt())
            setTypeface(null, Typeface.BOLD)
        }
        root.addView(title)
        val sub = TextView(this).apply {
            text = "Prompt parts ko order mein paste karo. Har part alag block mein ho."
            textSize = 14f
            setTextColor(0xFF555568.toInt())
            setPadding(0, 8, 0, 16)
        }
        root.addView(sub)

        val perm = makeButton("1. Enable Accessibility") {
            startActivity(Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS))
        }
        root.addView(perm, lp())
        val openGemini = makeButton("2. Open Gemini") {
            val launch = packageManager.getLaunchIntentForPackage("com.google.android.apps.bard")
            if (launch != null) startActivity(launch)
            else Toast.makeText(this, "Gemini app nahi mila. Pehle Gemini install karo.", Toast.LENGTH_LONG).show()
        }
        root.addView(openGemini, lp())

        val label = TextView(this).apply {
            text = "Prompt sequence"
            textSize = 17f
            setTypeface(null, Typeface.BOLD)
            setTextColor(0xFF202033.toInt())
            setPadding(0, 16, 0, 8)
        }
        root.addView(label)

        prompts = EditText(this).apply {
            hint = "PART 1: ...\\n\\n---NEXT---\\n\\nPART 2: ..."
            gravity = Gravity.TOP or Gravity.START
            minLines = 9
            maxLines = 16
            textSize = 14f
            setPadding(12, 12, 12, 12)
            setBackgroundColor(0xFFFFFFFF.toInt())
            setText(prefs.getString("prompts", ""))
        }
        root.addView(prompts, LinearLayout.LayoutParams(-1, 0, 1f))

        val note = TextView(this).apply {
            text = "Parts ko ---NEXT--- se separate karo. Gemini mein chat open karke Start dabao. App visible UI controls use karega; response timing Gemini ke layout par depend karti hai."
            textSize = 12f
            setTextColor(0xFF666677.toInt())
            setPadding(0, 10, 0, 8)
        }
        root.addView(note)

        root.addView(makeButton("START AUTOMATION") {
            val chunks = splitPrompts(prompts.text.toString())
            if (chunks.isEmpty()) {
                Toast.makeText(this, "Pehle prompt parts add karo.", Toast.LENGTH_SHORT).show()
            } else if (!isAccessibilityEnabled()) {
                Toast.makeText(this, "Pehle Accessibility enable karo.", Toast.LENGTH_LONG).show()
                startActivity(Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS))
            } else {
                prefs.edit().putString("prompts", prompts.text.toString())
                    .putString("queue", chunks.joinToString("\n\u001E\n"))
                    .putInt("index", 0).putBoolean("running", true)
                    .putBoolean("sent", false).apply()
                status.text = "Running — Gemini chat par jao."
                Toast.makeText(this, "Automation ready. Gemini open rakho.", Toast.LENGTH_LONG).show()
            }
        }, lp())
        root.addView(makeButton("STOP") {
            prefs.edit().putBoolean("running", false).apply()
            status.text = "Stopped"
        }, lp())
        status = TextView(this).apply {
            text = if (prefs.getBoolean("running", false)) "Running" else "Ready"
            textSize = 13f
            setTextColor(0xFF444455.toInt())
            setPadding(0, 10, 0, 0)
        }
        root.addView(status)
        setContentView(root)
    }

    private fun splitPrompts(raw: String): List<String> =
        raw.split(Regex("(?im)^\\s*---NEXT---\\s*$"))
            .map { it.trim() }.filter { it.isNotEmpty() }

    private fun isAccessibilityEnabled(): Boolean {
        val am = getSystemService(Context.ACCESSIBILITY_SERVICE) as AccessibilityManager
        return am.getEnabledAccessibilityServiceList(android.accessibilityservice.AccessibilityServiceInfo.FEEDBACK_ALL_MASK)
            .any { it.resolveInfo.serviceInfo.packageName == packageName }
    }

    private fun makeButton(label: String, action: () -> Unit) = Button(this).apply {
        text = label
        isAllCaps = false
        textSize = 14f
        setOnClickListener { action() }
    }

    private fun lp() = LinearLayout.LayoutParams(-1, LinearLayout.LayoutParams.WRAP_CONTENT).apply {
        bottomMargin = 7
    }
}
